<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

	//This method writes the top n cities and its sales quantity for a given year.
	//To this page, we're provided year and count
	$intYear = $_GET['year'];
	$count = $_GET['count'];
	//XML Data container
	//If number of items to show on chart is less than 10, we stagger them
	//else we show as rotated
	if ($count>10)
		$labelFormatting = "labelDisplay=ROTATE;slantLabels=1";
	else
		$labelFormatting = "labelDisplay=STAGGER";
	
	# Create Object of FusionCharts class
	$FC=new FusionCharts("Column3D",750,300);
	# set SWF Path
	$FC->setSWFPath("FusionCharts/");
	
	# Define Charts Parameter	
	$strParam  = "caption=" . $intYear . " - Top " . $count . " Cities By Sales;palette=" . getPalette() . ";animation=" . getAnimationState() . ";formatNumberScale=0;numberPrefix=$; labeldisplay=ROTATE;slantLabels=1;seriesNameInToolTip=0;sNumberSuffix= pcs.;showValues=0; plotSpacePercent=10;" . $labelFormatting;
	
	# Set Chart Parameter
	$FC->setChartParams($strParam);
	# Get sales by city XML
	getSalesByCityXML($intYear,$count,true, $FC);
	
	//Add some styles to increase caption font size
	$FC->defineStyle("CaptionFont","font","color=" . getCaptionFontColor() . ";size=15");
	$FC->defineStyle("SubCaptionFont","font","bold=0");
	
	# apply style to Chart�s CAPTION and SUBCAPTION
    $FC->applyStyle("caption","CaptionFont");
    $FC->applyStyle("SubCaption","SubCaptionFont");
		
	//Output it
	header('Content-type: text/xml');
	print $FC->getXML();
?>