<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

	//This method writes the top n employees  and their sales quantity for a given year.
	//To this page, we're provided year and count
	$intYear = $_GET['year'];
	$count = $_GET['count'];
	
	# Create Object of FusionCharts class
	$FC = new FusionCharts("Pie3D",400,225);
	# set SWF Path
	$FC->setSWFPath("FusionCharts/");
					
	# Define Charts Parameter
	$strParam  = "caption=Top 5 Employees for " . $intYear . ";palette=" . getPalette() . "; animation=" . getAnimationState() . ";subCaption=(Click to slice out or right click to choose rotation mode);YAxisName=Sales Achieved;YAxisName=Quantity;showValues=0;numberPrefix=$; formatNumberScale=0;showPercentInToolTip=0";
	# Set Chart Parameter
	$FC->setChartParams($strParam);
	# Get sale per employee
	getSalePerEmpXML($intYear,$count,false,false,true,$FC);
	
	#Add some styles to increase caption font size
	$FC->defineStyle("CaptionFont","font","color=" . getCaptionFontColor() . ";size=15");
	$FC->defineStyle("SubCaptionFont","font","bold=0");
	
	# apply style to Chart�s CAPTION and SUBCAPTION
	$FC->applyStyle("caption","CaptionFont");
	$FC->applyStyle("SubCaption","SubCaptionFont");
							
	//Output it
	header('Content-type: text/xml');
	print $FC->getXML();
?>