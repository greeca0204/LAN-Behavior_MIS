<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

	//This page provides the XML data for shipping delay by cities.
	//It needs two parameters necessarily:
	// - Year
	// - Country
	$intYear = $_GET['year'];
	$country = $_GET['country'];
	
	# Create Object of FusionCharts class
	$FC=new FusionCharts("Column3D",750,300);
	# set SWF Path
	$FC->setSWFPath("FusionCharts/");
	
	# Define Charts Parameter
	$strParam  = "caption=" . $country . " - Average delay in Shipping Time;yAxisName=Delay (in days);xAxisName=City;palette=" . getPalette() . ";animation=" . getAnimationState() . ";showValues=0;formatNumberScale=1;numberSuffix= days;numDivLines=5";
	
	# Set Chart Parameter
	$FC->setChartParams($strParam);
	
	# get average shiping time city XML
	getAvgShipTimeCityXML($intYear, $country,true, $FC);
	
	# Add some styles to increase caption font size
	$FC->defineStyle("CaptionFont","font","color=" . getCaptionFontColor() . ";size=15");
	$FC->defineStyle("SubCaptionFont","font","bold=0");
	
	# apply style to Chart�s CAPTION and SUBCAPTION
    $FC->applyStyle("caption","CaptionFont");
    $FC->applyStyle("SubCaption","SubCaptionFont");
	
	# Set Chart Parameter	
	header('Content-type: text/xml');
	print $FC->getXML();
?>