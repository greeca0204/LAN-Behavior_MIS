<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

//This method writes the inventory by product data for a given category.
$strCat = $_GET['category'];
//XML Data container

# Create Object of FusionCharts class
$FC=new FusionCharts("MSColumn3DLineDY",750,300);
# set SWF Path
$FC->setSWFPath("FusionCharts/");
# set chart delimiter
$FC->setParamDelimiter ("\n");

# Define Charts Parameter	
$strParam  = "caption=" . $strCat . " - Inventory by Products\nPYAxisName=Cost of Inventory \nSYAxisName=Units in Inventory\nxAxisName=Products\npalette=" . getPalette() . "\nanimation=" . getAnimationState() . "\nshowValues=0\nformatNumberScale=0\nnumberPrefix=$\nlabelDisplay=STAGGER\nseriesNameInToolTip=0";
# Set Chart Parameter
$FC->setChartParams($strParam);
# Get inventory by prod xml
getInventoryByProdXML($strCat,true,$FC);

//Add some styles to increase caption font size
$FC->defineStyle("CaptionFont","font","color=" . getCaptionFontColor() . "\nsize=15");
$FC->defineStyle("SubCaptionFont","font","bold=0");
	
# apply style to Chart�s CAPTION and SUBCAPTION
$FC->applyStyle("caption","CaptionFont");
$FC->applyStyle("SubCaption","SubCaptionFont");

//Output it
header('Content-type: text/xml');
# Get XML
print $FC->getXML();
?>