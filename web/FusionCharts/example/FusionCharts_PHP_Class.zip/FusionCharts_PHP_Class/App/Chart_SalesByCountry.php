<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/FusionCharts.php");
include("Includes/PageLayout.php");
include("DataGen.php");
?>
<HTML>
<HEAD>
	<TITLE>
	FusionCharts v3 Demo Application - Sales By Country
	</TITLE>
	<?php
	//You need to include the following JS file, if you intend to embed the chart using JavaScript.
	//Embedding using JavaScripts avoids the "Click to Activate..." issue in Internet Explorer
	//When you make your own charts, make sure that the path to this JS file is correct. Else, you would get JavaScript errors.
	?>	
	<SCRIPT LANGUAGE="Javascript" SRC="FusionCharts/FusionCharts.js"></SCRIPT>		
	<SCRIPT LANGUAGE="JavaScript">			
	//We keep flags to check whether the charts have loaded successfully.
	//By default, we assume them to false. When each chart loads, it calls
	//a JavaScript function FC_Rendered, in which we'll update the flags
	var cityChartLoaded=false;
	var customerChartLoaded=false;
	
	/**
	 * FC_Rendered function is invoked by all FusionCharts charts which are registered
	 * with JavaScript. To this function, the chart passes its own DOM Id. We can check
	 * against the DOM id and update charts or loading flags.
	 *	@param	DOMId	Dom Id of the chart that was succesfully loaded.
	*/
	function FC_Rendered(DOMId){
		//Here, we update the loaded flags for each chart
		//Since we already know the charts in the page, we use conditional loop
		switch(DOMId){
			case "CityDetails":				
				cityChartLoaded = true;
				break;
			case "CustomerDetails":				
				customerChartLoaded = true;
				break;
		}
		return;
	}	
	
	/** 
	 * updateChart method is invoked when the user clicks on a column chart.
	 * In this method, we get the year and country of the column which was clicked
	 * and then send request for new XML data to update the bottom 2 charts. 
	 *	@param	year		Year for which we need the dta
	 *	@param	country		Country for which we need drill down
	*/		
	function updateChart(year, country){			
		//Update the chart if it's loaded
		if (cityChartLoaded){
			//DataURL for the chart
			var strURL = "Data_SalesByCity.php?year=" + year + "&country=" + country;
					
			//Sometimes, the above URL and XML data gets cached by the browser.
			//If you want your charts to get new XML data on each request,
			//you can add the following line:
			strURL = strURL + "&currTime=" + getTimeForURL();
			//getTimeForURL method is defined below and needs to be included
			//This basically adds a ever-changing parameter which bluffs
			//the browser and forces it to re-load the XML data every time.
								
			//URLEncode it - NECESSARY.
			strURL = escape(strURL);
		
			//Get reference to chart object using Dom ID "CityDetails"
			var chartObj = getChartFromId("CityDetails");			
			//Send request for XML
			chartObj.setDataURL(strURL);
		} else {
			//Show error
			alert("Please wait for the charts to load.");
			return;
		}
		
		if (customerChartLoaded){
			//Update other chart too (Customers)
			//DataURL for the chart
			var strURL = "Data_SalesByCountryCus.php?year=" + year + "&country=" + country;
			strURL = strURL + "&currTime=" + getTimeForURL();
			strURL = escape(strURL);
		
			var ordersChartObj = getChartFromId("CustomerDetails");			
			//Send request for XML
			ordersChartObj.setDataURL(strURL);		
		} else {
			//Show error
			alert("Please wait for the charts to load.");
			return;
		}
	}
	/**
	 * getTimeForURL method returns the current time 
	 * in a URL friendly format, so that it can be appended to
	 * dataURL for effective non-caching.
	*/
	function getTimeForURL(){
		var dt = new Date();
		var strOutput = "";
		strOutput = dt.getHours() + "_" + dt.getMinutes() + "_" + dt.getSeconds() + "_" + dt.getMilliseconds();
		return strOutput;
	}
	</SCRIPT>
	<LINK REL='stylesheet' HREF='Style.css' />
</HEAD>
<BODY topmargin='0' leftmargin='0' bottomMargin='0' rightMargin='0' bgColor='#EEEEEE'>
<?php
	//Request the year for which we've to show data.
    //If year has not been provided, we default to 1996
	if (!isset($_GET['year']) || $_GET['year']=="")
		$intYear=1996;
    else
        $intYear = $_GET['year'];

	//Render page headers
	echo render_pageHeader();
	//Render the main table open
	echo render_pageTableOpen();
?>
<table width='875' align='center' cellspacing='0' cellpadding='0'>
	<tr>
	<td align='center'>
	<?php
		
		# Create Object of FusionCharts class
		$FC=new FusionCharts("MSColumn3DLineDY",850,300,"NewChart");
		# set SWF Path
		$FC->setSWFPath("FusionCharts/");
	
		# Set Chart Parameter
		$strParam  = "caption=Sales By Country for " . $intYear . ";palette=" . getPalette() . "; animation=" . getAnimationState() . ";formatNumberScale=0;numberPrefix=$;labeldisplay=ROTATE;slantLabels=1;seriesNameInToolTip=0; sNumberSuffix= pcs.;showValues=0;plotSpacePercent=10";
		
		# Set Chart Parameter
		$FC->setChartParams($strParam);
		
		# Get Sales by Country XML
		getSalesByCountryXML($intYear,-1,true,false,$FC);
		
		# Add some styles to increase caption font size
		$FC->defineStyle("CaptionFont","font","color=" . getCaptionFontColor() . ";size=15");
		$FC->defineStyle("SubCaptionFont","font","bold=0");
	
		# apply style to Chart�s CAPTION and SUBCAPTION
    	$FC->applyStyle("caption","CaptionFont");
    	$FC->applyStyle("SubCaption","SubCaptionFont");
		
		# Set Register With JS true
		$FC->setInitParam("registerwithjs",true);
		
		# Render objects to XML, Create Chart Output
		$FC->renderChart();
	
	?>
	</td>
	</tr>
</table>

<?php	
	//Separator line
	echo drawSepLine();
?>	

<P align='center' class='text'>Click on a column above to drill down to city and customer details.</P>

<?php
	//Separator line
	echo drawSepLine();
?>	

	<table width='800' align='center'>
		<tr>
		<td width='400' align='center' style='BORDER-RIGHT:#EEEEEE 1px solid;'>
		<?php
		//Combi 2D Chart with changed "No data to display" message
		//We initialize the chart with <chart></chart>
		echo renderChart("FusionCharts/MSCombiDY2D.swf?ChartNoDataText=Please select a country above.", "", "<chart></chart>", "CityDetails", 420, 250, false, true);
		?>
		</td>
		<td width='400' align='center'>
		<?php
		//Combi 2D Chart with changed "No data to display" message
		//We initialize the chart with <chart></chart>
		echo renderChart("FusionCharts/MSCombiDY2D.swf?ChartNoDataText=Please select a country above.", "", "<chart></chart>", "CustomerDetails", 420, 250, false, true);
		?>
		</td>
		</tr>
	</table>	
<?php
//Close the main table
echo render_pageTableClose();
?>
</BODY>
</HTML>