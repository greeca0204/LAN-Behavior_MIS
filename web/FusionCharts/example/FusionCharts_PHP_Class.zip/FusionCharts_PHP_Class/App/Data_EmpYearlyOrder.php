<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

//This method writes the number of orders the employee processes yearly data as XML.
//To this page, we're provided employeed Id.
$eId = $_GET['id'];

# Create Object of FusionCharts class
$FC=new FusionCharts("Column3D",750,300);
# set SWF Path
$FC->setSWFPath("FusionCharts/");
# Define Charts Parameter
$strParam = "caption=Number of Orders - " . getEmployeeName($eId) . ";xAxisName=Year;palette=" . getPalette() . ";animation=" . getAnimationState() ;
# Set Chart Parameter
$FC->setChartParams($strParam);

# Get the data for employee for 3 years - 1994,95,96
$FC->addChartData(getNumOrders($eId,1994),"label=1994","");
$FC->addChartData(getNumOrders($eId,1995),"label=1995","");
$FC->addChartData(getNumOrders($eId,1996),"label=1996","");


# Output it
header('Content-type: text/xml');
# Get XML
print $FC->getXML();

function getNumOrders($eId, $intYear) {		
    // Function to connect to the DB
    $link = connectToDB();
		
	//Retrieve the data
	$strSQL = "SELECT Count(OrderID) As Total FROM FC_Orders WHERE YEAR(OrderDate)=" . $intYear . " and EmployeeID=" . $eId;
    $result = mysql_query($strSQL) or die(mysql_error());
    if ($result) {
        if (mysql_num_rows($result) > 0) {
            $ors = mysql_fetch_array($result);
            $getNumOrders = $ors['Total'];
        } else {
            $getNumOrders = 0;
        }
    }
    mysql_close($link);

	return $getNumOrders;
}
?>