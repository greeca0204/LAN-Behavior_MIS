<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

	//This page outputs the sales by category XML data for the the specified year.
	//Request the year for which we've to show data.
	//If year has not been provided, we default to 1996
	if ((!isset($_GET['year'])) || $_GET['year']=="")
		$intYear = 1996;
    else
        $intYear = $_GET['year'];
    
	# Create Object of FusionCharts class    
	$FC = new FusionCharts("MSColumn3DLineDY",450,325);
	# set SWF Path
	$FC->setSWFPath("FusionCharts/");
	# Define Charts Parameter	
	$strParam = "caption=Category wise Sales for " . $intYear . ";subcaption=(Click on a column to see monthly sales for that category in the chart below this);XAxisName=Month;palette=" . getPalette() . ";animation=" . getAnimationState() . ";formatNumberScale=0;numberPrefix=$;showValues=0;numDivLines=4;legendPosition=BOTTOM";
	# Set Chart Parameter
	$FC->setChartParams($strParam);
	# Get cumulative Sale by category XML
	getCumulativeSalesByCatXML($intYear,true,$FC);
	
	# Add some styles to increase caption font size
	$FC->defineStyle("CaptionFont","font","color=" . getCaptionFontColor() . ";size=15");
	$FC->defineStyle("SubCaptionFont","font","bold=0");
	
	# apply style to Chart�s CAPTION and SUBCAPTION
    $FC->applyStyle("caption","CaptionFont");
    $FC->applyStyle("SubCaption","SubCaptionFont");
		
	# Write the XML data to output stream - WITHOUT ANY HTML Tag.
	header('Content-type: text/xml');
	print $FC->getXML();
?>
