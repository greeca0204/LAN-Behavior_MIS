<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

	# This method writes the sales by product data for a given category for a given year
	$intYear = $_GET['year'];
	$intCatId = $_GET['catId'];
	
	# Create Object of FusionCharts class
	$FC=new FusionCharts("MSColumn3DLineDY",750,300);
	# set SWF Path
	$FC->setSWFPath("FusionCharts/");
	# set delimiter
	$FC->setParamDelimiter("\n");
	
	# Define Charts Parameter
	$strParam = "caption=" . getCategoryName($intCatId) . " - Product wise sales in " . $intYear . "\nPYAXisName=Revenue\nSYAxisName=Units Sold\nxAxisName=Products\npalette=" . getPalette() . "\nanimation=" . getAnimationState() . "\nshowValues=0\nformatNumberScale=0\nnumberPrefix=$\nlabelDisplay=STAGGER\nseriesNameInToolTip=0";
	# Set Chart Parameter
	$FC->setChartParams($strParam);
	# Get sales by product category XML
	getSalesByProdCatXML($intYear,$intCatId,true,$FC);
	
	# Add some styles to increase caption font size
	$FC->defineStyle("CaptionFont","font","color=" . getCaptionFontColor() . "\nsize=15");
	$FC->defineStyle("SubCaptionFont","font","bold=0");
	
	# apply style to Chart�s CAPTION and SUBCAPTION
    $FC->applyStyle("caption","CaptionFont");
    $FC->applyStyle("SubCaption","SubCaptionFont");
			
	# Output it
	header('Content-type: text/xml');
	print $FC->getXML();
?>