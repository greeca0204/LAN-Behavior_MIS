<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

    //This page outputs the sales by product (in a category) XML data for the the specified 
	//year and month.	
	$intYear = $_GET['year'];
	$intMonth = $_GET['month'];
	$intCatId = $_GET['catId'];
	
	# Create Object of FusionCharts class
	$FC=new FusionCharts("MSColumn3DLineDY",875,350,"TopEmployees");
	# set SWF Path
	$FC->setSWFPath("FusionCharts/");
	
	# Define Charts Parameter
	$strParam  = "caption=" . getCategoryName($intCatId) . " - Product wise Sales for " . MonthName($intMonth, false) . " " . $intYear . ";XAxisName=Product;palette=" . getPalette() . "; animation=" . getAnimationState() . ";formatNumberScale=0;numberPrefix=$;showValues=0; PYAxisName=Revenue;SYAxisName=Units Sold;seriesNameInToolTip=0";
	# Set Chart Parameter
	$FC->setChartParams($strParam);
	
	# Get sales by product XML
	getSalesByProdXML($intYear, $intMonth, $intCatId, true, $FC);
	
	# Add some styles to increase caption font size
	$FC->defineStyle("CaptionFont","font","color=" . getCaptionFontColor() . ";size=15");
	$FC->defineStyle("SubCaptionFont","font","bold=0");
	
	# apply style to Chart�s CAPTION and SUBCAPTION
    $FC->applyStyle("caption","CaptionFont");
    $FC->applyStyle("SubCaption","SubCaptionFont");
	
	# Write the XML data to output stream - WITHOUT ANY HTML Tag.
	header('Content-type: text/xml');
	print $FC->getXML();
?>
