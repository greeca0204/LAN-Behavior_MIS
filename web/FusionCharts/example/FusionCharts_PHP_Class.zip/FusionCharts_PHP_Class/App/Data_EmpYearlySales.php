<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

//This method writes the employee yearly sales data as XML.
//To this page, we're provided employeed Id.
$eId = $_GET['id'];

# Create Object of FusionCharts class
$FC=new FusionCharts("Column3D",750,300);
# set SWF Path
$FC->setSWFPath("FusionCharts/");

# Define Charts Parameter
$strParam  = "caption=Yearly Sales Figure for " . getEmployeeName($eId) . ";xAxisName=Year; palette=" . getPalette() . ";animation=" . getAnimationState() . ";numberPrefix=$; formatNumberScale=0";
# Set Chart Parameter
$FC->setChartParams($strParam);

# Add Chart Data
$FC->addChartData(getSalesFigure($eId,1994),"label=1994","");
$FC->addChartData(getSalesFigure($eId,1995),"label=1995","");
$FC->addChartData(getSalesFigure($eId,1996),"label=1996","");


//Output it
header('Content-type: text/xml');
# get XML
print $FC->getXML();


function getSalesFigure($eId, $intYear) {

    // Function to connect to the DB
    $link = connectToDB();
		
	//Retrieve the data
	$strSQL = "SELECT e.lastname, SUM(d.quantity*p.UnitPrice) As Total FROM FC_Employees as e,FC_Orders as o, FC_OrderDetails as d, FC_Products as p WHERE YEAR(OrderDate)=" . $intYear . " and e.EmployeeID=" . $eId . " and e.EmployeeID=o.EmployeeID and o.OrderID=d.OrderID and d.ProductID=p.ProductID GROUP BY e.lastname,e.EmployeeID ORDER BY Total DESC";
    $result = mysql_query($strSQL) or die(mysql_error());
    if ($result) {
        if (mysql_num_rows($result) > 0) {
            $ors = mysql_fetch_array($result);
            $salesFigure = $ors['Total'];
        } else {
            $salesFigure = 0;
        }
    }
    mysql_close($link);

    return $salesFigure;
}
?>