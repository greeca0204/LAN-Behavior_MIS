<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

	//This method writes the sales data for customers in a country for the given year
	//To this page, we're provided country and year
	$intYear = $_GET['year'];
	$country = $_GET['country'];
	
	# Create Object of FusionCharts class
	$FC=new FusionCharts("MSCombiDY2D",750,300);
	# set SWF Path
	$FC->setSWFPath("FusionCharts/");
	# set delimiter
	$FC->setParamDelimiter ("\n");
	
	# Define Charts Parameter
	$strParam = "caption=" . $country . " - Customer wise Sales Figure for " . $intYear . "\nxAxisName=Customer\npalette=1\nanimation=" . getAnimationState() . "\nformatNumberScale=0\nnumberPrefix=$\nlabeldisplay=ROTATE\nslantLabels=1\nseriesNameInToolTip=0\nsNumberSuffix= pcs.\nshowValues=0\nshowBorder=1\nshowLegend=0";
	
	# Set Chart Parameter
	$FC->setChartParams($strParam);
	# Get sales by country customer XML
	getSalesByCountryCustomerXML($intYear,$country,true,$FC);
	
	# Add some styles to increase caption font size
	$FC->defineStyle("CaptionFont","font","size=13");
	$FC->defineStyle("SubCaptionFont","font","bold=0");
	
	# apply style to Chart�s CAPTION and SUBCAPTION
    $FC->applyStyle("caption","CaptionFont");
    $FC->applyStyle("SubCaption","SubCaptionFont");
	
		
	//Output it
	header('Content-type: text/xml');
	print $FC->getXML();
?>