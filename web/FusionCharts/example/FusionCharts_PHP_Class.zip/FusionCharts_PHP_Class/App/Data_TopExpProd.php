<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

	//This method writes the top n expensive items and its sales quantity for a given year.
	//To this page, we're provided year and count
	$intYear = $_GET['year'];
	$count = $_GET['count'];
	
	//We do a conditional label formatting
	//If number of items to show on chart is less than 10, we wrap them
	//else we show as rotated
	if ($count>10)
		$labelFormatting = "labelDisplay=ROTATE;slantLabels=1";
	else
		$labelFormatting = "labelDisplay=WRAP";
	
	# Create Object of FusionCharts class
	$FC=new FusionCharts("MSColumn3DLineDY",750,300);
	# set SWF Path
	$FC->setSWFPath("FusionCharts/");
	# Define Charts Parameter
	$strParam  = "caption=Sale of " . $count . " Most Expensive Products for " . $intYear . "; PYAxisName=Unit Price;SYAxisName=Units Sold for the year;palette=" . getPalette() . ";animation=" . getAnimationState() . ";formatNumberScale=0;numberPrefix=$;seriesNameInToolTip=0;sNumberSuffix= pcs.;showValues=0;plotSpacePercent=10;" . $labelFormatting;
	# Set Chart Parameter
	$FC->setChartParams($strParam);
	# Get expensive product XML
	getExpensiveProdXML($intYear,$count,true,$FC);
	
	//Add some styles to increase caption font size
	$FC->defineStyle("CaptionFont","font","color=" . getCaptionFontColor() . ";size=15");
	$FC->defineStyle("SubCaptionFont","font","bold=0");
	
	# apply style to Chart�s CAPTION and SUBCAPTION
    $FC->applyStyle("caption","CaptionFont");
    $FC->applyStyle("SubCaption","SubCaptionFont");
	
	//Output it
	header('Content-type: text/xml');
	print $FC->getXML();
?>