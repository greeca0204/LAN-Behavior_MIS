<?php
include("Includes/Connection_inc.php");
include("Includes/FusionCharts_Gen.php");
include("Includes/Functions.php");
include("DataGen.php");

	//This method writes the sales data for a given city in a country for the given year
	//To this page, we're provided country and year
	$intYear = $_GET['year'];
	$country = $_GET['country'];
	
	# Create Object of FusionCharts class
	$FC=new FusionCharts("MSCombiDY2D",750,300);
	# set SWF Path
	$FC->setSWFPath("FusionCharts/");
	
	# Define Charts Parameter
	$strParam = "caption=" . $country . " - City wise Sales Figure for " . $intYear . ";xAxisName=City;palette=1;animation=" . getAnimationState() . ";formatNumberScale=0;numberPrefix=$;labeldisplay=ROTATE;slantLabels=1;seriesNameInToolTip=0;sNumberSuffix= pcs.;showValues=0;showBorder=1;showLegend=0";
	# Set Chart Parameter
	$FC->setChartParams($strParam);
	# Get Sales by country XML	
	getSalesByCountryCityXML($intYear,$country,true,$FC);
	
	# Add some styles to increase caption font size
	$FC->defineStyle("CaptionFont","font","color=" . getCaptionFontColor() . ";size=15");
	$FC->defineStyle("SubCaptionFont","font","bold=0");
	
	# apply style to Chart�s CAPTION and SUBCAPTION
    $FC->applyStyle("caption","CaptionFont");
    $FC->applyStyle("SubCaption","SubCaptionFont");
	
	# Output it
	header('Content-type: text/xml');
	print $FC->getXML();
?>