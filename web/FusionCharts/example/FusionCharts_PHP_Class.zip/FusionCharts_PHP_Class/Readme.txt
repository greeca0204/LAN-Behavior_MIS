FusionCharts Blueprint Application - PHP (Using PHP Class) + MySQL version
==================================================================

This demo application shows the capabilities of FusionCharts by integrating
it with PHP and MySQL. The database script is contained in FusionChartsDB folder.

Based on what you intend to use, change the data connection string in 
App/Includes/Connection_inc.php

After that, run App/Default.php to view the application. Make sure you copy
all the files from App folder, keeping the folder structure intact.

PLEASE NOTE THAT THIS DEMO APPLICATION JUST USES A HANDFUL OF CHARTS
FROM FUSIONCHARTS SUITE FOR DEMO PURPOSE. FUSIONCHARTS OFFERS A LOT
MORE VARIETY OF CHARTS, WHICH IS PRESENT IN EVALUATION DOWNLOAD.

Support Information
==================================================================
Website: http://www.fusioncharts.com
Email: support@fusioncharts.com